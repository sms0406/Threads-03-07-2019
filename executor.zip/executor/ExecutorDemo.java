package pack1;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class MyRunnable implements Runnable {
	
	public void run() {
		for(int i=0;i<5;i++)
		     System.out.println(Thread.currentThread().getName() + "  "+i);
	}

}

class MyCallable implements Callable<Integer>{

	@Override
	public Integer call() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("inside callable");
		return 10;
	}
	
}
 public class ExecutorDemo{
	 public static void main(String[] args) throws InterruptedException, ExecutionException{
		/*MyRunnable runnable  = new MyRunnable();
		Thread thread = new Thread(runnable);
		Thread thread2 = new Thread(runnable);
		thread.start();
		thread2.start();*/
		 
		 ExecutorService service = Executors.newSingleThreadExecutor();
		 MyCallable callable = new MyCallable();
		Future<Integer> f=service.submit(callable);
		System.out.println("return value of callable "+f.get());
		 /*for(int i=0;i<5;i++) {
			 MyRunnable runnable  = new MyRunnable();
			 service.execute(runnable);
		 }*/
		 service.shutdown();
		for(int i=0;i<5;i++)
			System.out.println("from main thread "+i);
		System.out.println("main ends");
	}
 }
