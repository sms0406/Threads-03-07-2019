package day8;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableDemo {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		CallableFactorialTask task = new CallableFactorialTask(5);
		Future<Integer> f = executorService.submit(task);
		Integer val = f.get();
		System.out.println(val);
		executorService.shutdown();
	}
}
class CallableFactorialTask implements Callable<Integer> {
	private int num = 0;
	public CallableFactorialTask(int num){
		this.num = num;
	}
	@Override
	public Integer call() throws Exception {
		int prod = 1;
		for (int i = 2; i <= num; i++)
			prod *= i;
		return prod;
	}
}
