package mthread;

public class ThreadDemo2 {
	public static void main(String[] args) throws InterruptedException{
		MyRunnable runnable = new MyRunnable();
		Thread thread = new Thread(runnable);
		thread.setPriority(Thread.MAX_PRIORITY);
		thread.start();
		thread.join();
		for(int i=0;i<5;i++){
			System.out.println("inside main");
		}
		System.out.println("main thread prioroty " + Thread.currentThread().getPriority());
	}

}
class MyRunnable implements Runnable{

	@Override
	public void run() {
		for(int i=0;i<5;i++) {
			if(i==2)
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			System.out.println("inside MyThread "+i);
			
		}
		System.out.println("my thread priority "+Thread.currentThread().getPriority());
		
	}
	
}
