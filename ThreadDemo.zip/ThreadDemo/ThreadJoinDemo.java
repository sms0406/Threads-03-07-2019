package threading;

class MyThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			for(int i=1;i<=5;i++) {
				System.out.println(Thread.currentThread().getName() + " : "+i);
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName() + " ends");

	}

}
public class ThreadJoinDemo {
	public static void main(String[] args) throws Exception{
		MyThread mt =new MyThread();
		Thread t1 = new Thread(mt, "one");
		Thread t2 = new Thread(mt, "two");
		//Thread t = new Thread()
		t1.start();
	
		t1.join();
		t2.start();
		t2.join();
		
		/*try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		
		System.out.println("main ends");

	}

}
