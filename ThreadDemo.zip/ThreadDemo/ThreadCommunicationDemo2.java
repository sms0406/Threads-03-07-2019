package threading;


class Container {
    private int itemNo;
     
    synchronized int get() {
    	System.out.println("Got "+itemNo);
    	return itemNo;
    }
    synchronized void put(int n) {
    	this.itemNo=n;
    	System.out.println("Put "+itemNo);
     }
}
class Producer implements Runnable{
	Container c;
	Producer(Container c){
		this.c=c;
		
	}
	public void run() {
		int i=0;
		while(true) {
			c.put(i++);
		}
		
	}
	
}

class Consumer implements Runnable{
	Container c;
	Consumer(Container c){
		this.c=c;
		
	}
	public void run() {
		while(true) {
			c.get();
		}
		
	}
}
public class ThreadCommunicationDemo2 {
	public static void main(String[] args) {
		Container container = new Container();
		Thread consumer = new Thread(new Consumer(container),"Consumer");
		consumer.start();
		Thread producer = new Thread(new Producer(container),"Producer");
		producer.start();
		System.out.println("Prog ends");
		
	}

}
