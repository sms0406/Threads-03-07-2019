package threading;


class Container1 {
    private int itemNo;
    boolean valueSet=false; 
    synchronized int get() {
    	while(!valueSet) {
    		try {
    			
    			wait();
    		}catch(InterruptedException e) {
    			System.out.println("interrupted exception caught "+e.getMessage());
    		}
    	}
    	System.out.println("Got "+itemNo);
    	valueSet=false;
    	notify();
    	return itemNo;
    }
    synchronized void put(int n) {
    	while(valueSet) {
    		try {
    			wait();    			
    		}catch(InterruptedException e) {
    			System.out.println("interrupted exception caught "+e.getMessage());
    		}
    	}
    	this.itemNo=n;
    	valueSet=true;    	
    	System.out.println("Put "+n);
    	notify();
     }
}
class Producer1 implements Runnable{
	Container1 c;
	Producer1(Container1 c){
		this.c=c;
		
	}
	public void run() {
		int i=0;
		while(true) {
			c.put(i++);
		}
		
	}
	
}

class Consumer1 implements Runnable{
	Container1 c;
	Consumer1(Container1 c){
		this.c=c;
		
	}
	public void run() {
		while(true) {
			c.get();
		}
		
	}
}
public class ThreadCommunicationDemo3 {
	public static void main(String[] args) {
		Container1 c = new Container1();
		Thread consumer = new Thread(new Consumer1(c),"Consumer");
		consumer.start();
		Thread producer = new Thread(new Producer1(c),"Producer");
		producer.start();
		
		
	}

}
