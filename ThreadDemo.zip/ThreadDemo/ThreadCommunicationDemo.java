package threading;
class Customer{
	int balance=1000;
	synchronized void withdraw(int amount)  {
		System.out.println("going to withdraw...");
		
		if(balance<amount) {
			System.out.println("less balance..waiting for deposit...");
			try {
				wait();
			}catch(InterruptedException e) {}
			
		}
		balance = balance-amount;
		System.out.println("withdraw completed"); 
		
		
	}
	
	synchronized void deposit(int amount){  
		System.out.println("going to deposit...");  
		this.balance+=amount;  
		System.out.println("deposit completed... ");  
		notify();  

		}  
		
}
class DepositThread extends Thread{
	Customer customer;
	DepositThread(Customer c){customer=c;}
	public void run() {
		customer.deposit(10000);
		
	}
}
class WithdrawThread extends Thread{
	Customer customer;
	WithdrawThread(Customer c){customer=c;}
	public void run() {
		customer.withdraw(15000);
		
	}
}

public class ThreadCommunicationDemo {
	public static void main(String args[]){  
		final Customer c=new Customer();  
		/*new Thread(){  
		public void run(){c.withdraw(15000);}  
		}.start();  
		new Thread(){  
		public void run(){c.deposit(10000);}  
		}.start();  
		  */
		
	
		WithdrawThread withdraw = new WithdrawThread(c);
		withdraw.start();
		DepositThread deposit = new DepositThread(c);
		deposit.start();
		
		} 

}
