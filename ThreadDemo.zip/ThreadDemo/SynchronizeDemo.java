package threading;

class Account{
	private int balance=50;
	public int getBalance() {
		return balance;
	}
	public void withdraw(int amount) {
		balance=balance-amount;
	}
}

class AccountThread implements Runnable{
	private Account acct = new Account();
	public void run() {
		for(int x=0;x<5;x++) {
			makeWithdrawal(10);
			if(acct.getBalance()<0) {
				System.out.println("account overdrawn");
			}
		}
	}
	public synchronized void  makeWithdrawal(int amount) {
		if(acct.getBalance()>=amount) {
			System.out.println(Thread.currentThread().getName() + " is going to withdraw ");
			try {
				System.out.println(Thread.currentThread().getName() + " is going to sleep");
				Thread.sleep(500);
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()  + " woke up");
		
			acct.withdraw(amount);
		
			System.out.println(Thread.currentThread().getName() + " completes withdrawal "+ acct.getBalance());
		} else {
			System.out.println(" not enough money in account for " +Thread.currentThread().getName() + " to withdraw " + acct.getBalance());
		}
	}
}
public class SynchronizeDemo {
	public static void main(String[] args) {
		AccountThread at = new AccountThread();
	
		Thread jack = new Thread(at,"Jack");
		Thread jill = new Thread(at, "Jill");
		jack.start();
		jill.start();
		System.out.println("main ends");
	}

}
