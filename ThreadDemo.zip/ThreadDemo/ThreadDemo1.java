package mthread;

public class ThreadDemo1 {
public static void main(String[] args) {
	MyThread thread = new MyThread();
	thread.setName("one");
	thread.start();
	
	
	MyThread thread2 = new MyThread();
	thread2.setName("two");
	thread2.start();	
	for(int i=0;i<5;i++)
		System.out.println("inside main method "+Thread.currentThread().getName()+" "+i);
	
	}
}
class MyThread extends Thread{
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println("inside run of MyThread "+Thread.currentThread().getName()+"  "+i);
		}
		
	}
	
}
